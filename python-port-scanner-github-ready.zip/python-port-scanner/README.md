# Python TCP Port Scanner

A beginner-friendly TCP port scanner written in Python using the standard
`socket` library.

## Features

- TCP connect scanning using `socket.connect_ex()`
- Custom start/end port range
- Configurable socket timeout
- Optional banner grabbing
- Command-line arguments
- No third-party Python packages required

## Project Structure

```text
python-port-scanner/
├── scanner.py
├── README.md
└── .gitignore
```

## Requirements

- Python 3.x
- A system/network that you own or are authorized to test

No external Python packages are required.

## Installation

Clone the repository:

```bash
git clone https://github.com/YOUR-USERNAME/python-port-scanner.git
cd python-port-scanner
```

## Usage

Scan ports 20–1024:

```bash
python3 scanner.py 127.0.0.1
```

Scan a specific range:

```bash
python3 scanner.py 127.0.0.1 -s 1 -e 100
```

Scan without banner grabbing:

```bash
python3 scanner.py 127.0.0.1 -s 1 -e 100 --no-banner
```

Set a custom timeout:

```bash
python3 scanner.py 127.0.0.1 -s 1 -e 100 -t 0.5
```

## Example Output

```text
============================================================
Simple TCP Port Scanner
============================================================
Target : 127.0.0.1
IP     : 127.0.0.1
Ports  : 1-100
Timeout: 1.0s
============================================================
[+] Port    22 OPEN -> SSH-2.0-OpenSSH
[+] Port    80 OPEN -> (No Banner)
```

The exact output depends on the services running on the target.

## How It Works

1. Creates a TCP socket with `socket.AF_INET` and `socket.SOCK_STREAM`.
2. Sets a timeout so the scan does not wait indefinitely.
3. Uses `connect_ex()` to attempt a TCP connection.
4. A return value of `0` indicates that the connection succeeded.
5. If enabled, the script sends a small request and attempts to read a service banner.
6. The socket is closed after each port check.

## Security / Legal Notice

This project is for educational and authorized security testing only.

Only scan:
- Your own computer or lab
- Systems where you have explicit permission
- Intentionally provided security-training targets

Do not use this tool to scan random public IP addresses, networks, or services
without authorization.

## Learning Goals

This project demonstrates:

- Python socket programming
- TCP connections
- Port scanning fundamentals
- Timeouts and exception handling
- Basic service/banner identification
- Command-line argument handling

## Possible Improvements

Future versions could add:

- Multithreaded scanning
- Service detection
- CSV/JSON report generation
- Progress indicators
- IPv6 support
- Logging
- Basic OS/service fingerprinting
