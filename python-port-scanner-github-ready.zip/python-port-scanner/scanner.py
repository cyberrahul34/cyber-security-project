#!/usr/bin/env python3
"""
Simple TCP Port Scanner with optional banner grabbing.

Use this tool only against systems you own or have explicit permission to test.
"""

import argparse
import socket


def scan_port(target: str, port: int, timeout: float = 1.0, grab_banner: bool = True) -> None:
    """Check whether a TCP port is open and optionally try to read its banner."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)

    try:
        result = sock.connect_ex((target, port))

        if result == 0:
            banner = ""

            if grab_banner:
                try:
                    sock.sendall(b"Hello\r\n")
                    banner = sock.recv(1024).decode(errors="replace").strip()
                except (socket.timeout, ConnectionError, OSError):
                    pass

            if banner:
                print(f"[+] Port {port:5} OPEN -> {banner}")
            else:
                print(f"[+] Port {port:5} OPEN -> (No Banner)")

    except socket.gaierror:
        print(f"[-] Could not resolve target: {target}")
    except OSError:
        pass
    finally:
        sock.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Simple TCP port scanner with optional banner grabbing."
    )
    parser.add_argument("target", help="Hostname or IP address to scan")
    parser.add_argument(
        "-s",
        "--start-port",
        type=int,
        default=20,
        help="Starting TCP port (default: 20)",
    )
    parser.add_argument(
        "-e",
        "--end-port",
        type=int,
        default=1024,
        help="Ending TCP port (default: 1024)",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=1.0,
        help="Socket timeout in seconds (default: 1.0)",
    )
    parser.add_argument(
        "--no-banner",
        action="store_true",
        help="Disable banner grabbing",
    )

    args = parser.parse_args()

    if not (1 <= args.start_port <= 65535):
        parser.error("start-port must be between 1 and 65535")

    if not (1 <= args.end_port <= 65535):
        parser.error("end-port must be between 1 and 65535")

    if args.start_port > args.end_port:
        parser.error("start-port cannot be greater than end-port")

    try:
        target_ip = socket.gethostbyname(args.target)
    except socket.gaierror:
        print(f"[-] Could not resolve target: {args.target}")
        return

    print("=" * 60)
    print("Simple TCP Port Scanner")
    print("=" * 60)
    print(f"Target : {args.target}")
    print(f"IP     : {target_ip}")
    print(f"Ports  : {args.start_port}-{args.end_port}")
    print(f"Timeout: {args.timeout}s")
    print("=" * 60)

    for port in range(args.start_port, args.end_port + 1):
        scan_port(
            target_ip,
            port,
            timeout=args.timeout,
            grab_banner=not args.no_banner,
        )


if __name__ == "__main__":
    main()
